import React from 'react';
import { Button, Form, Container } from 'react-bootstrap';
import { Link } from 'react-router-dom'; // Import Link for navigation
import 'bootstrap/dist/css/bootstrap.min.css';

const AdminDashboard = () => {
  return (
    <h1>
    Admin
    </h1>
  );
};

export default AdminDashboard;
