import React from 'react';
import { Button, Form, Container } from 'react-bootstrap';
import { Link } from 'react-router-dom'; // Import Link for navigation
import 'bootstrap/dist/css/bootstrap.min.css';

const UserDashboard = () => {
  return (
    <h1>
    User
    </h1>
  );
};

export default UserDashboard;
