import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Signup from './components/Signup';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const authToken = localStorage.getItem('authToken');
    if (authToken) {
      fetch('http://localhost:3000/user', {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      })
        .then((response) => {
          if (response.ok) {
            return response.json();
          } else {
            throw new Error('Invalid token');
          }
        })
        .then((user) => {
          if (user.role === 'admin') {
            setIsAdmin(true);
          }
          setIsLoggedIn(true);
        })
        .catch((error) => {
          setIsLoggedIn(false);
          setIsAdmin(false);
        });
    } else {
      setIsLoggedIn(false);
      setIsAdmin(false);
    }
  }, []);

  return (
      <Routes>
        <Route exact path="/" element= {isLoggedIn ? (isAdmin ? <AdminDashboard /> : <UserDashboard />) : <Login />}/>
        <Route path="/login" element={<Login/>} />
        <Route path="/signup" element={<Signup/>} />
      </Routes>
  );
}

export default App;
